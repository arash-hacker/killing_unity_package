﻿using UnityEngine;
using System.Collections;

public class TileMap : MonoBehaviour {

	public Vector2 mapSize = new Vector2(20, 10);

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
