﻿using UnityEngine;
using System.Collections;

public class TileMap : MonoBehaviour {

	public Vector2 mapSize = new Vector2(20, 10);
	public Texture2D texture2D;
	public Vector2 tileSize = new Vector2();
	public Object[] spriteReferences;
	public Vector2 gridSize = new Vector2();
	public int pixelsToUnits = 100;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
