﻿using UnityEngine;
using System.Collections;

public class Graph {

	public int rows = 0;
	public int cols = 0;
	public Node[] nodes;

	public Graph(int[,] grid){
		rows = grid.GetLength (0);
		cols = grid.GetLength (1);

		nodes = new Node[grid.Length];
		for (var i = 0; i < nodes.Length; i++) {
			var node = new Node();
			node.label = i.ToString();
			nodes[i] = node;
		}
	}

}
