﻿using UnityEngine;
using System.Collections;

public class Graph {

	public int rows = 0;
	public int cols = 0;
	public Node[] nodes;

}
