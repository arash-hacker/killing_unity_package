﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Search {

	public Graph graph;
	public List<Node> reachable;
	public List<Node> explored;
	public List<Node> path;
	public Node goalNode;
	public int iterations;
	public bool finished;

	public Search(Graph graph){
		this.graph = graph;
	}
}
