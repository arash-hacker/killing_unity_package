﻿using UnityEngine;
using System.Collections;

public class PathfindingTest : MonoBehaviour {

	// Use this for initialization
	void Start () {
		int[,] map = new int[5, 5]{
			{0,1,0,0,0},
			{0,1,0,0,0},
			{0,1,0,0,0},
			{0,1,0,0,0},
			{0,0,0,0,0}
		};
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
